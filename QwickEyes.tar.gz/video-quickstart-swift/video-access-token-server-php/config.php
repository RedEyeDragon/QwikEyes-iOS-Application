
<?php
// see README.md for an explanation of these config params
$TWILIO_ACCOUNT_SID = 'AC00937c4ba8f375515a5333c6448bb156';
$TWILIO_API_KEY = 'SK6888fb7e9cc953ca80784edddd604c0b';
$TWILIO_API_SECRET = 'LDh3ybIwb8bDRuzvaLVjsgBq6zWYD5T5';
