
<?php
// see README.md for an explanation of these config params
$TWILIO_ACCOUNT_SID = 'your account sid here';
$TWILIO_API_KEY = 'your API key here';
$TWILIO_API_SECRET = 'your API secret here';
